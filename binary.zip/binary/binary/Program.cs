﻿using System;
using System.Linq;

namespace binary
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("decimal to binary 15 " + decimaltobinary(15));
            Console.WriteLine("binary to decimal 100 " + binarytodecimal(100.ToString()));
        }
        static public string decimaltobinary(int number)
        {
            string binary = "";
            do
            {
                binary = binary + number % 2;
                number = number / 2;
            } while (number != 0);
            return new string(binary.ToCharArray().Reverse().ToArray());
        }
        static public double binarytodecimal(string binary)
        {
            int i = 0;
            double val = 0;
            foreach(char s in binary.ToCharArray().Reverse())
            {
                val = val + (double.Parse(s.ToString()) * Math.Pow(2, i));
                i = i + 1;
            }
            return val;
        }
    }
}
